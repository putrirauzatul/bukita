<?php
define('base_url', 'http://localhost/bukita/public');
define('DB_HOST', 'localhost');
define('DB_USER', 'if0_35552135');
define('DB_PASS', 'kKrkgd10YC1ChQj');
define('DB_NAME', 'if0_35552135_latihan_mvc');
